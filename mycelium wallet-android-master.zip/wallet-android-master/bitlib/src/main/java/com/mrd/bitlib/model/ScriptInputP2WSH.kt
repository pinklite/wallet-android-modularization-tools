package com.mrd.bitlib.model

class ScriptInputP2WSH(scriptBytes: ByteArray) : ScriptInput(scriptBytes)