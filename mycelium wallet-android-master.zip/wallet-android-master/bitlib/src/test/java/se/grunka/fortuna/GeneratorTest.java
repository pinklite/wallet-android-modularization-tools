package se.grunka.fortuna;

import org.junit.Before;

public class GeneratorTest {

    @SuppressWarnings("unused")
   private Generator generator;

    @Before
    public void before() throws Exception {
        generator = new Generator();
    }
}
