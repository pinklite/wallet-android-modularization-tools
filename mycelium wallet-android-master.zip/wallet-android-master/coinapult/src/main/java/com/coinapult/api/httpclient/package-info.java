/**
 * 
 */
/**
 * @author Guilherme Polo
 *
 */
package com.coinapult.api.httpclient;
