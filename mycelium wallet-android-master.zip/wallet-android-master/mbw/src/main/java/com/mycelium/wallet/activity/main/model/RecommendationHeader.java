package com.mycelium.wallet.activity.main.model;

public class RecommendationHeader extends RecommendationInfo {
    public static final int HEADER_TYPE = 4;

    public RecommendationHeader() {
        super(HEADER_TYPE);
    }
}
