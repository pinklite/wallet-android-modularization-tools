package com.mycelium.wallet.activity.news.event

import com.mycelium.wallet.external.mediaflow.model.News


class NewsFavoriteEvent(val news: News)