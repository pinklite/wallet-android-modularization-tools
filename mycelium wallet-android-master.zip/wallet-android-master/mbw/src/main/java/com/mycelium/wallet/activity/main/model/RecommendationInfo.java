package com.mycelium.wallet.activity.main.model;

public class RecommendationInfo {
    public int type;

    public RecommendationInfo(int type) {
        this.type = type;
    }
}
