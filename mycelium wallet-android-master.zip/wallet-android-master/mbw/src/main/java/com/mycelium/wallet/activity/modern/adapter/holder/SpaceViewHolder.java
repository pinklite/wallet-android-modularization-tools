package com.mycelium.wallet.activity.modern.adapter.holder;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class SpaceViewHolder extends RecyclerView.ViewHolder {
    public SpaceViewHolder(View itemView) {
        super(itemView);
    }
}
