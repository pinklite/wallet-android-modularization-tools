package com.mycelium.wallet.activity.main.model;

public class RecommendationFooter extends RecommendationInfo {
    public static final int FOOTER_TYPE = 2;

    public RecommendationFooter() {
        super(FOOTER_TYPE);
    }
}
