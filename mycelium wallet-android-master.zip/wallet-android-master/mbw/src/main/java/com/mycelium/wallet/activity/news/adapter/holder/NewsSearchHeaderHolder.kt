package com.mycelium.wallet.activity.news.adapter.holder

import android.view.View
import androidx.recyclerview.widget.RecyclerView


class NewsSearchHeaderHolder(itemView: View) : RecyclerView.ViewHolder(itemView)