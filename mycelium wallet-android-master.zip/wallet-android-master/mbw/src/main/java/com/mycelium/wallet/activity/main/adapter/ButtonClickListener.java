package com.mycelium.wallet.activity.main.adapter;

import com.mycelium.wallet.activity.main.model.ActionButton;

public interface ButtonClickListener {
    void onClick(ActionButton actionButton);
}
