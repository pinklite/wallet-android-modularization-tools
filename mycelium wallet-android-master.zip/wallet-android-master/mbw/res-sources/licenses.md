Files used for the localTraderLocalOnly.xcf:

* thumbs-up: [public domain](https://pixabay.com/en/hand-thumb-sign-ok-yes-positive-311121/)
* guys: [public domain](https://openclipart.org/detail/201468/men-shacking-hand-4-differents-versions)
* earth: [public domanin](https://openclipart.org/detail/3320/earth)
