The "Mycelium Bitcoin Wallet".
