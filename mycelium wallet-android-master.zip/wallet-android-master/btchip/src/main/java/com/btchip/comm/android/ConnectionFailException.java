package com.btchip.comm.android;

public class ConnectionFailException extends Exception {
    ConnectionFailException(String message) {
        super(message);
    }
}
